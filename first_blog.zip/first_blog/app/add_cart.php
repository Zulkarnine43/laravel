<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class add_cart extends Model
{
    //
    protected $fillable=['quality','qty','productId','radio'];
}
