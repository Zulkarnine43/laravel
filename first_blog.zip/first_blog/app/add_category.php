<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class add_category extends Model
{
    //
    protected $fillable=['category_name','category_description','long_description'];
}
