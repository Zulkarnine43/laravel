<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class shopping_form extends Model
{
    //
    protected $fillable =['fullname','email','phone_number','address'];
}
