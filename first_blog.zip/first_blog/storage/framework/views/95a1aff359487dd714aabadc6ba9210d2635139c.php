;
<?php $__env->startSection('body'); ?>


    <div class="content">
        <div class="single-wl3">

            <div class="container">
                <div class="row">
                    Dear You have to give us product shipping info to complete vlauable order
                    <div class="col-md-11 col-md-offset-1">
                        <form action="<?php echo e(route('paymenttype')); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                        <table class="table table-bordered">
                            <tr>
                                <th>Catch On Delivery</th>
                                <td><input type="radio" name="payment_type" value="cash" >cash on Delivery</td>
                            </tr>
                            <tr>
                                <th>paypal</th>
                                <td><input type="radio" name="payment_type" value="paypal" >paypal</td>
                            </tr>
                            <tr>
                                <th>bkash</th>
                                <td><input type="radio" name="payment_type" value="Bkash" >Bkash</td>
                            </tr>

                            <tr>
                                <th></th>
                                <td><input type="submit" name="btn_type" value="Confirm Order" ></td>
                            </tr>
                        </table>
                    </form>
                    </div>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('admin.headerFooter', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xammpp\htdocs\first_blog\resources\views/payment/payment_type.blade.php ENDPATH**/ ?>