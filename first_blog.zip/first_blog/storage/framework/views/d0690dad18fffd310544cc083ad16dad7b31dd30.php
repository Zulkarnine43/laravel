<?php $__env->startSection('body'); ?>
    <div class="content">
        <!--login-->
        <div class="login">
            <div class="main-agileits">
                <div class="form-w3agile">
                    <h3  class="col-md-offset-3 col-md-4 text-center text-success">Login If you register already</h3>
                    <h3><?php echo e(Session::get('message')); ?></h3>

                    <form action="<?php echo e(route('loginCheck')); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <div class="key">
                            <i class="fa fa-envelope" aria-hidden="true"></i>
                            <input class="col-md-offset-3 col-md-4 text-center"  type="text" value="" name="email" placeholder="Email">
                            <div class="clearfix"></div>
                        </div>
                        <div class="key">
                            <i class="fa fa-lock" aria-hidden="true"></i>
                            <input  class="col-md-offset-3 col-md-4 text-center" type="password" value="" name="password" placeholder="Password">
                            <div class="clearfix"></div>
                        </div>
                        <input class="col-md-offset-3 col-md-4 text-center text-success" type="submit" name="btn" value="Login">
                    </form>
                </div>

                <div class="float-right">
                    <a href="#" class="forg-left">Forgot Password</a>
                    <a href="registered.html" class="forg-right">Register</a>
                    <div class="clearfix"></div>
                </div>

            </div>
        </div>
        <!--login-->
    </div>


    <?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.headerFooter', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xammpp\htdocs\New folder\first_blog\resources\views/customer/login_info.blade.php ENDPATH**/ ?>