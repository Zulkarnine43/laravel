<?php $__env->startSection('body'); ?>

    <div class="row">
        <div class="col-md-12">
            <div class="panel">
                <div class="panel-body">
                    <h3>Manage Brands Info</h3>
                    <h3 class="text-center text-success"><?php echo e(Session::get('message')); ?></h3>
                    <table class="table table-bordered small text-center">
                        <tr>
                            <th>Sl No</th>
                            <th>Category Name</th>
                            <th>Brand Name </th>
                            <th>Product Name </th>
                            <th>Product Price</th>
                            <th>Product Quantity</th>
                            <th>Product Description</th>
                            <th>long_description</th>
                            <th>product_image</th>
                            <th>Action</th>
                        </tr>
                        <?php ($i=1); ?>;
                        <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($i++); ?></td>
                                <td><?php echo e($product->category_name); ?></td>
                                <td><?php echo e($product->brand_name); ?></td>
                                <td><?php echo e($product->product_name); ?></td>
                                <td><?php echo e($product->product_price); ?></td>
                                <td><?php echo e($product->product_quantity); ?></td>
                                <td><?php echo e($product->product_description); ?></td>
                                <td><?php echo e($product->long_description); ?></td>
                                <td><?php echo e($product->product_image); ?></td>
                                <td>
                                    <a href="<?php echo e(route('productEdit',['id' =>$product->id])); ?>" class="glyphicon-edit btn-dark">edit</a>
                                    <a href="<?php echo e(route('productDelete',['id' =>$product->id])); ?>" class="glyphicon-trash btn-success">delete</a>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </table>
                </div>
            </div>
        </div>
    </div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xammpp\htdocs\New folder\first_blog\resources\views/product/manage_product.blade.php ENDPATH**/ ?>