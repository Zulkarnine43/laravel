<?php $__env->startSection('body'); ?>

            <div class="table-responsive">
                <h3 class=" text-center text-success">shipping for this order</h3>
                <table class="table table-dark table-bordered">
                    <tr>
                        <th>full name</th>
                        <th>phone number</th>
                        <th>email name</th>
                        <th>address </th>

                    </tr>
                    <tr>
                        <td><?php echo e(Session::get('Cfullname')); ?></td>
                        <td><?php echo e(Session::get('customerEmail')); ?></td>
                        <td><?php echo e(Session::get('Cphone_number')); ?></td>
                        <td><?php echo e(Session::get('Caddress')); ?></td>

                    </tr>
                </table>
            </div>

        <div class="table-responsive">
                <h3 class=" text-center text-success">payment for this order</h3>
                <table class="table table-dark table-bordered">
                    <tr>
                        <th>payment type</th>
                    </tr>
                    <tr>
                        <td><?php echo e(Session::get('type')); ?></td>
                    </tr>
                </table>
            </div>

<div class="table-responsive">
       <h3 class="text text-success text-center">Product</h3>
    <table class="table table-dark table-bordered">

        <tr>
            <th scope="col">id</th>
            <th scope="col">product-name</th>
            <th scope="col">product-price</th>
            <th scope="col">product-quantity</th>
            <th>total price</th>

            <?php ($i=1); ?>

        </tr>
        <tr>
            <td><?php echo e($i++); ?></td>
            <td><?php echo e(Session::get('product_name')); ?></td>
            <td><?php echo e(Session::get('product_price')); ?></td>
            <td><?php echo e(Session::get('product_quantity')); ?></td>
            <td>1260</td>

        </tr>

    </table>
</div>
    <a href="<?php echo e(route('downloadInfo')); ?>">Download pdf</a>
    <?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.headerFooter', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xammpp\htdocs\first_blog\resources\views/payment/order_info.blade.php ENDPATH**/ ?>