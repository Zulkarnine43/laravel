;
<?php $__env->startSection('body'); ?>

                        <h3>Shipping Info goes here.....</h3>
                    <form action="<?php echo e(route('fromSubmit')); ?>" method="POST" class="form-right">
                        <?php echo csrf_field(); ?>

                        <div class="content">
                            <!--login-->
                            <div class="login">
                                <div class="main-agileits">
                                    <div class="form-w3agile form1">
                                        <h3>Register</h3>
                                        <div class="key">
                                            <i class="fa fa-user" aria-hidden="true"></i>
                                            <input  type="text" class="input-lg float-lg-right" name="fullname" value="" placeholder="fullname" >

                                            <div class="clearfix"></div>
                                        </div>

                                        <div class="key">
                                            <i class="fa fa-user" aria-hidden="true"></i>
                                            <input  type="text" class="input-lg" name="email" value=""  placeholder="email">
                                            <div class="clearfix"></div>
                                        </div>

                                        <div class="key">
                                            <i class="fa fa-envelope" aria-hidden="true"></i>
                                            <input  type="text" class="input-lg" name="phone_number" placeholder=" phone_number">
                                            <div class="clearfix"></div>
                                        </div>
                                        <div class="key">
                                            <i class="fa fa-envelope" aria-hidden="true"></i>
                                            <input  type="text" class="input-lg" name="address" placeholder="address">
                                            <div class="clearfix"></div>
                                        </div>

                                        <input class="text-success" type="submit" name="btn" value="Submit">
                                    </div>

                                </div>
                            </div>
                            <!--login-->
                        </div>
                    </form>
                </div>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('admin.headerFooter', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xammpp\htdocs\first_blog\resources\views/shipping/shipping_form.blade.php ENDPATH**/ ?>