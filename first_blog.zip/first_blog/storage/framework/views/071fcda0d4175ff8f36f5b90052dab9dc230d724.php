<?php $__env->startSection('body'); ?>

<?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="col-md-3 product-men">
        <div class="men-pro-item simpleCart_shelfItem">
            <div class="men-thumb-item">
                <img src="<?php echo e(asset($product->product_image)); ?>" alt="" class="pro-image-front">
                <img src="<?php echo e(asset($product->product_image)); ?>" alt="" class="pro-image-back">
                <img src="" alt="" class="pro-image-back">
                <div class="men-cart-pro">
                    <div class="inner-men-cart-pro">
                        <a href="single.html" class="link-product-add-cart">Quick View</a>
                    </div>
                </div>
                <span class="product-new-top">New</span>

            </div>
            <div class="item-info-product ">
                <h4><a href="single.html"><?php echo e($product->product_name); ?></a></h4>
                <div class="info-product-price">
                    <span class="item_price"><?php echo e($product->product_price); ?></span>
                    <!-- <del>$69.71</del>-->
                </div>
                <a href="<?php echo e(route('product_detail',['id'=>$product->id])); ?>" class="item_add single-item hvr-outline-out button2">Add to cart</a>
            </div>
        </div>
    </div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.headerFooter', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xammpp\htdocs\New folder\first_blog\resources\views/product/allproduct.blade.php ENDPATH**/ ?>